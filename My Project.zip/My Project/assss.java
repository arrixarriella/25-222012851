 class assss {
    public static void main(String[] args) {
        int a;
        //the farmer have to be classfied according to cow they have.
        if (a>=8) {
            System.out.println("The farmer is Very rich");
        }
        
       else if (a<=5) {
        System.out.println("The farmer is rich");
       }
       else if (a>=1) {
        System.out.println("The farmer is average");
       }
       else 
       System.out.println("poor");
    }
}


public class ass7 {
    public static void main(String args[]){  
        System.out.println(10<<2);
        System.out.println(10<<3);
        System.out.println(20<<2);
        System.out.println(15<<4);
        }}  


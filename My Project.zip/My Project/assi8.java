public class assi8 {
        public static void main(String[] args) {  
            do{  
                System.out.println("do while loop");  
            }while(true);  
        }  
        }  


 class ass9 {
    public static void main(String[] args) {
        int a;
        //money earned are calculated in dollars
        if (a<=500) {
            System.out.println("You are not allowed to get the loan");
        }
        //
       else if (a<=1000) {
        System.out.println("You are allowed to get lower loan");
       }
       else if (a>=5000) {
        System.out.println("You are allowed to get the loan");
       }
       else 
       System.out.println("invalid");
    }
}

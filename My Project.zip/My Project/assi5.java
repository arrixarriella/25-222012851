public class assi5 {
        public static void main(String args[])
        {
            int i = 1;
            while (i < 6) {
                System.out.println("Hello World");
                i++;
            }
        }
    }


class ass4 {
    public static void main(String args[]){  
        int a=10;  
        int b=-10;  
        boolean c=true;  
        boolean d=false;  
        System.out.println(~a);
        System.out.println(~b);
        System.out.println(!c);
        System.out.println(!d);
        }
    }  
public class assi1 {
        public static void main(String[] args) {
          int n = 5; 
          for (int i = 1; i <= n; ++i) {
            System.out.println("Perfect time");
          }
        }
      }


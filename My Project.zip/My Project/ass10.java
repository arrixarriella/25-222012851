class ass10 {
    public static void main(String[] args) {
        string fnames='alier';
        switch (fnames) {
            case ange: System.out.println("Ange");
                
                break;
        case jeannette: System.out.println("Jeannette");
        break;
        case alier: System.out.println("Alier");
        break;
            default: System.out.println("Not in the specified names");
                
        }
    }
}

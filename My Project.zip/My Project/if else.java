class ass8 {
    public static void main(String[] args) {
        int a=10;
        int b=15;
        if (a>b) {
         System.out.println("a is greater");   
        }
        else
        System.out.println("b is greater");
    }
}

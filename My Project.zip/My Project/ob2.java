public class ob2 {
public static int interest(int p,int r,int t) {
    return p*r*t/100;
}
public static void main(String[] args) {
    int a=100000;
    int b=5;
    int c=5;
    int result=interest(a, b, c);
    System.out.println("The interest he have to pay is " +result);
}
}